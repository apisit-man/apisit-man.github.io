const NS = "http://www.w3.org/2000/svg";

const levels = [
  {
    title: "วงกลมแบ่งครึ่ง",
    nodes: [
      {x:220,y:260},{x:400,y:100},{x:580,y:260},{x:400,y:420}
    ],
    edges: [
      {a:0,b:1,c:[250,120]},{a:1,b:2,c:[550,120]},
      {a:2,b:3,c:[550,400]},{a:3,b:0,c:[250,400]},
      {a:0,b:2}
    ]
  },
  {
    title: "สี่เหลี่ยมสองช่อง",
    nodes: [
      {x:260,y:90},{x:540,y:90},{x:260,y:260},{x:540,y:260},{x:260,y:430},{x:540,y:430}
    ],
    edges: [
      {a:0,b:1},{a:1,b:3},{a:3,b:5},{a:5,b:4},{a:4,b:2},{a:2,b:0},{a:2,b:3}
    ]
  },
  {
    title: "วงกลมกากบาท",
    nodes: [
      {x:400,y:75},{x:620,y:260},{x:400,y:445},{x:180,y:260},{x:400,y:260}
    ],
    edges: [
      {a:0,b:1,c:[570,100]},{a:1,b:2,c:[570,420]},
      {a:2,b:3,c:[230,420]},{a:3,b:0,c:[230,100]},
      {a:0,b:4},{a:4,b:2},{a:3,b:4},{a:4,b:1}
    ]
  },
  {
    title: "ว่าวสองชั้น",
    nodes: [
      {x:400,y:65},{x:610,y:260},{x:400,y:455},{x:190,y:260},{x:400,y:260}
    ],
    edges: [
      {a:0,b:1},{a:1,b:2},{a:2,b:3},{a:3,b:0},
      {a:3,b:4},{a:4,b:1}
    ]
  },
  {
    title: "เรือใบพิชิตยอด",
    nodes: [
      {x:390,y:70},{x:390,y:250},{x:620,y:250},
      {x:180,y:360},{x:420,y:360},{x:560,y:470},{x:690,y:360}
    ],
    edges: [
      {a:0,b:1},{a:0,b:2},{a:1,b:2},
      {a:1,b:4},{a:3,b:4},{a:3,b:5},{a:5,b:6},{a:6,b:4},
      {a:4,b:5}
    ]
  }
];

let currentLevel = 0;
let usedEdges = new Set();
let currentNode = null;
let dragging = false;
let attempts = 1;
let soundOn = true;
let completed = JSON.parse(localStorage.getItem("oneStrokeCompleted") || "[]");

const board = document.getElementById("board");
const guideLayer = document.getElementById("guideLayer");
const traceLayer = document.getElementById("traceLayer");
const nodeLayer = document.getElementById("nodeLayer");
const pointerGlow = document.getElementById("pointerGlow");
const message = document.getElementById("message");
const nextBtn = document.getElementById("nextBtn");
const winModal = document.getElementById("winModal");
const boardWrap = document.getElementById("boardWrap");
const confettiCanvas = document.getElementById("confettiCanvas");
const ctx = confettiCanvas.getContext("2d");

function edgePath(edge) {
  const l = levels[currentLevel], p1 = l.nodes[edge.a], p2 = l.nodes[edge.b];
  return edge.c
    ? `M ${p1.x} ${p1.y} Q ${edge.c[0]} ${edge.c[1]} ${p2.x} ${p2.y}`
    : `M ${p1.x} ${p1.y} L ${p2.x} ${p2.y}`;
}

function svgEl(tag, attrs={}) {
  const el = document.createElementNS(NS, tag);
  Object.entries(attrs).forEach(([k,v]) => el.setAttribute(k,v));
  return el;
}

function renderLevel() {
  usedEdges.clear();
  currentNode = null;
  dragging = false;
  attempts = 1;
  guideLayer.innerHTML = "";
  traceLayer.innerHTML = "";
  nodeLayer.innerHTML = "";
  nextBtn.disabled = true;
  winModal.hidden = true;
  message.className = "message";
  message.textContent = "แตะที่จุดเริ่มต้น แล้วลากต่อเนื่องไปตามเส้น";
  const l = levels[currentLevel];
  document.getElementById("levelLabel").textContent = `LEVEL ${currentLevel+1}`;
  document.getElementById("levelTitle").textContent = l.title;
  document.getElementById("movesDone").textContent = "0";
  document.getElementById("movesTotal").textContent = l.edges.length;
  document.getElementById("attempts").textContent = attempts;

  l.edges.forEach((e,i)=>{
    const path = svgEl("path",{d:edgePath(e),class:"guide","data-edge":i});
    guideLayer.appendChild(path);
  });
  l.nodes.forEach((n,i)=>{
    const c=svgEl("circle",{cx:n.x,cy:n.y,r:13,class:"node available","data-node":i});
    nodeLayer.appendChild(c);
  });
  updateLevelButtons();
}

function getSvgPoint(evt){
  const pt=board.createSVGPoint();
  const t=evt.touches?.[0] ?? evt;
  pt.x=t.clientX; pt.y=t.clientY;
  return pt.matrixTransform(board.getScreenCTM().inverse());
}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function nearestNode(p, radius=34){
  let best=-1,bestD=Infinity;
  levels[currentLevel].nodes.forEach((n,i)=>{
    const d=dist(p,n); if(d<radius && d<bestD){best=i;bestD=d}
  });
  return best;
}
function findEdge(a,b){
  return levels[currentLevel].edges.findIndex(e=>(e.a===a&&e.b===b)||(e.a===b&&e.b===a));
}
function beginAt(node){
  currentNode=node; dragging=true;
  nodeLayer.querySelectorAll(".node").forEach(n=>n.classList.remove("current"));
  nodeLayer.querySelector(`[data-node="${node}"]`)?.classList.add("current");
  message.textContent="ลากต่อไปตามเส้นที่เชื่อมกัน";
  playTone(420,.07);
}
function useEdge(edgeIndex,toNode){
  if(edgeIndex<0 || usedEdges.has(edgeIndex)) return false;
  usedEdges.add(edgeIndex);
  const edge=levels[currentLevel].edges[edgeIndex];
  guideLayer.querySelector(`[data-edge="${edgeIndex}"]`)?.classList.add("used");
  const path=svgEl("path",{d:edgePath(edge),class:"trace"});
  traceLayer.appendChild(path);
  currentNode=toNode;
  nodeLayer.querySelectorAll(".node").forEach(n=>n.classList.remove("current"));
  nodeLayer.querySelector(`[data-node="${toNode}"]`)?.classList.add("current");
  document.getElementById("movesDone").textContent=usedEdges.size;
  playTone(520+usedEdges.size*35,.045);
  if(usedEdges.size===levels[currentLevel].edges.length) win();
  return true;
}

function pointerDown(evt){
  evt.preventDefault();
  const p=getSvgPoint(evt), n=nearestNode(p);
  if(n>=0){
    if(usedEdges.size && currentNode!==n) return;
    beginAt(n);
    board.setPointerCapture?.(evt.pointerId);
  }
}
function pointerMove(evt){
  if(!dragging) return;
  evt.preventDefault();
  const p=getSvgPoint(evt);
  pointerGlow.setAttribute("cx",p.x); pointerGlow.setAttribute("cy",p.y);
  const n=nearestNode(p,40);
  if(n>=0 && n!==currentNode){
    const ei=findEdge(currentNode,n);
    if(ei>=0 && !usedEdges.has(ei)){
      useEdge(ei,n);
    } else if(ei>=0 && usedEdges.has(ei)){
      fail("เส้นนี้ถูกใช้แล้ว ลองเริ่มใหม่อีกครั้ง");
    }
  }
}
function pointerUp(evt){
  if(!dragging) return;
  dragging=false;
  pointerGlow.setAttribute("cx",-100);
  if(usedEdges.size && usedEdges.size<levels[currentLevel].edges.length){
    const available=levels[currentLevel].edges.some((e,i)=>!usedEdges.has(i)&&(e.a===currentNode||e.b===currentNode));
    if(!available) fail("ทางตัน! ลองวางแผนจุดเริ่มต้นใหม่");
    else {
      message.className="message";
      message.textContent="ยกมือแล้ว — กดเริ่มใหม่เพื่อทดลองอีกครั้ง";
      attempts++;
      document.getElementById("attempts").textContent=attempts;
    }
  }
}

function fail(text){
  dragging=false;
  message.className="message bad";
  message.textContent=text;
  boardWrap.classList.remove("shake"); void boardWrap.offsetWidth; boardWrap.classList.add("shake");
  playFail();
}
function resetLevel(){
  attempts++;
  const keepAttempts=attempts;
  renderLevel();
  attempts=keepAttempts;
  document.getElementById("attempts").textContent=attempts;
}
function win(){
  dragging=false;
  message.className="message good";
  message.textContent="สำเร็จ! คุณใช้ครบทุกเส้นโดยไม่ลากซ้ำ";
  nextBtn.disabled=currentLevel===levels.length-1;
  if(!completed.includes(currentLevel)){
    completed.push(currentLevel);
    localStorage.setItem("oneStrokeCompleted",JSON.stringify(completed));
  }
  updateLevelButtons();
  playWin();
  launchConfetti();
  setTimeout(()=>{
    document.getElementById("winTitle").textContent=currentLevel===levels.length-1?"คุณพิชิตครบทุกด่านแล้ว!":"ยอดเยี่ยมมาก!";
    document.getElementById("winText").textContent=`ผ่านด่าน ${currentLevel+1} ด้วยการลาก ${usedEdges.size} เส้น`;
    document.getElementById("modalNextBtn").style.display=currentLevel===levels.length-1?"none":"inline-block";
    winModal.hidden=false;
  },700);
}
function nextLevel(){
  if(currentLevel<levels.length-1){currentLevel++;renderLevel()}
}
function updateLevelButtons(){
  document.querySelectorAll(".level-pill").forEach((b,i)=>{
    b.classList.toggle("active",i===currentLevel);
    b.classList.toggle("completed",completed.includes(i));
    b.classList.remove("locked");
  });
}
function showHint(){
  const l=levels[currentLevel];
  const degree=l.nodes.map(()=>0);
  l.edges.forEach(e=>{degree[e.a]++;degree[e.b]++});
  const odd=degree.map((d,i)=>d%2?i:-1).filter(i=>i>=0);
  const suggested=(currentNode===null ? (odd[0] ?? 0) : currentNode);
  nodeLayer.querySelector(`[data-node="${suggested}"]`)?.classList.add("available");
  const nextEdge=l.edges.findIndex((e,i)=>!usedEdges.has(i)&&(e.a===suggested||e.b===suggested));
  if(nextEdge>=0){
    const el=guideLayer.querySelector(`[data-edge="${nextEdge}"]`);
    el?.classList.add("hint-edge");
    setTimeout(()=>el?.classList.remove("hint-edge"),2100);
  }
  message.className="message";
  message.textContent=odd.length===2
    ? "คำใบ้: รูปนี้ควรเริ่มจากหนึ่งในจุดที่มีจำนวนเส้นเชื่อมเป็นเลขคี่"
    : "คำใบ้: รูปนี้เริ่มที่จุดใดก็ได้ แต่ต้องวางแผนเส้นทางให้กลับมาครบ";
  playTone(760,.09);
}

let audioCtx;
function ensureAudio(){
  if(!audioCtx) audioCtx=new (window.AudioContext||window.webkitAudioContext)();
}
function playTone(freq,dur,type="sine",delay=0){
  if(!soundOn) return;
  ensureAudio();
  const o=audioCtx.createOscillator(),g=audioCtx.createGain();
  o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(.0001,audioCtx.currentTime+delay);
  g.gain.exponentialRampToValueAtTime(.14,audioCtx.currentTime+delay+.01);
  g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+delay+dur);
  o.connect(g).connect(audioCtx.destination);o.start(audioCtx.currentTime+delay);o.stop(audioCtx.currentTime+delay+dur+.02);
}
function playWin(){[523,659,784,1047].forEach((f,i)=>playTone(f,.18,"triangle",i*.11))}
function playFail(){playTone(180,.2,"sawtooth");setTimeout(()=>playTone(120,.25,"sawtooth"),90)}

function launchConfetti(){
  confettiCanvas.width=boardWrap.clientWidth*devicePixelRatio;
  confettiCanvas.height=boardWrap.clientHeight*devicePixelRatio;
  ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
  const colors=["#5ef0d0","#7c5cff","#ffd66b","#ff6b86","#ffffff"];
  const pieces=Array.from({length:110},()=>({
    x:boardWrap.clientWidth/2,y:boardWrap.clientHeight*.35,
    vx:(Math.random()-.5)*8,vy:-Math.random()*7-2,
    g:.16+Math.random()*.08,r:3+Math.random()*5,a:Math.random()*Math.PI,
    c:colors[Math.floor(Math.random()*colors.length)],life:80+Math.random()*40
  }));
  function tick(){
    ctx.clearRect(0,0,confettiCanvas.width,confettiCanvas.height);
    pieces.forEach(p=>{
      p.x+=p.vx;p.y+=p.vy;p.vy+=p.g;p.a+=.12;p.life--;
      ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.a);ctx.fillStyle=p.c;ctx.fillRect(-p.r,-p.r/2,p.r*2,p.r);ctx.restore();
    });
    if(pieces.some(p=>p.life>0)) requestAnimationFrame(tick);
  } tick();
}

board.addEventListener("pointerdown",pointerDown);
board.addEventListener("pointermove",pointerMove);
board.addEventListener("pointerup",pointerUp);
board.addEventListener("pointercancel",pointerUp);
document.getElementById("resetBtn").onclick=resetLevel;
document.getElementById("hintBtn").onclick=showHint;
document.getElementById("nextBtn").onclick=nextLevel;
document.getElementById("replayBtn").onclick=()=>{winModal.hidden=true;renderLevel()};
document.getElementById("modalNextBtn").onclick=()=>{winModal.hidden=true;nextLevel()};
document.getElementById("soundBtn").onclick=(e)=>{soundOn=!soundOn;e.currentTarget.textContent=soundOn?"🔊":"🔇"};
document.querySelectorAll(".level-pill").forEach(btn=>btn.onclick=()=>{currentLevel=Number(btn.dataset.level);renderLevel()});
winModal.addEventListener("click",e=>{if(e.target===winModal)winModal.hidden=true});

renderLevel();
